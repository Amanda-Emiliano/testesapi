<div align="center">

## API-26-02 - **aNota**

  
  <img width="500" height="250" alt="logo_aNota" src="https://github.com/user-attachments/assets/42125f8b-d927-4907-a851-851845e29249" />
 
  
  <h2>Equipe Lovelace</h2>

**Projeto Acadêmico | API 2° semestre 2026 | Fatec** <br>
**Faculdade de Tecnologia de São José dos Campos - Prof. Jessen Vidal**
  
</div>

----

## 🚀 Problema

O processo atual de gestão de avaliações impõe uma rotina operacional exaustiva aos docentes, caracterizada pela criação manual de provas, busca trabalhosa por conteúdos antigos em pastas descentralizadas e dificuldade em gerar questões inéditas. Além disso, a falta de histórico dificulta o acompanhamento do reuso de perguntas, o isolamento entre professores gera diferenças no nível das avaliações e a correção manual toma dias de trabalho, tornando todo o fluxo lento, repetitivo e engessado.

----

## 📋 Backlog do Produto

| Rank | Prioridade | User Story | Sprint | Story Points | Status |
|:------:|:------------:|------------|:--------:|:--------:|:--------:|
| 1 | Alta | Como professor, quero gerenciar questões e respostas para ter um portfólio do meu material usado em avaliações. | 1 e 2 | 8 | ✅ | 
| 2 | Alta | Como professor, quero manter um histórico de quando utilizei uma questão para evitar repetição excessiva de conteúdo. | 1 e 2 | 8 | ✅ | 
| 3 | Alta | Como professor, quero selecionar e organizar questões para montar as provas e centralizar o processo de avaliação.  | 1 e 2 | 8 | ✅ | 
| 4 | Média | Como professor, quero aplicar provas com data e hora definidas para que todos os alunos da turma realizem a prova no mesmo período. | 1 e 2 | 5 | ⬜ | 
| 5 | Média | Como professor, quero divulgar o gabarito da avaliação para que o aluno possa consultar. | 1 e 3 | 2 | ⬜ | 
| 6 | Média | Como professor, quero que as provas sejam pré-corrigidas para evitar repetições desnecessárias. | 1 e 3 | 5 | ⬜ | 
| 7 | Média | Como professor, desejo que as alternativas das respostas de múltipla escolha e associação sejam embaralhadas para evitar o compartilhamento de respostas entre os alunos. | 1 e 3 | 5 | ⬜ | 
| 8 | Baixa | Como professor, quero filtrar as minhas questões por matéria, nível de dificuldade e tipo de pergunta para que eu encontre o meu material com mais facilidade. | 1 e 3 | 8 | ⬜ | 
| 9 | Baixa | Como professor, quero acessar o material de outros professores para analisar o nível de avaliação de outros cursos e disciplinas. | 1 e 3 | 3 | ⬜ | 
| 10 | Baixa | Como professor, quero cadastrar o peso das avaliações para facilitar o cálculo da média final. | 1 e 3 | 2 | ⬜ | 
| 11 | Baixa | Como aluno, quero ter acesso ao gabarito da avaliação para avaliar meu desempenho. | 1 e 3 | 2 | ⬜ | 
| 12 | Baixa | Como aluno, quero ver a minha média final para acompanhar meu desempenho ao longo do semestre. | 1 e 3 | 2 | ⬜ | 
| 13 | Baixa | Como professor, quero cadastrar notas de atividades extras para o cálculo da média final do aluno. | 1 e 3 | 2 | ⬜ | 
| 14 | Baixa | Como aluno, quero ver o agendamento das minhas próximas avaliações para organizar meus estudos. | 1 e 3 | 3 | ⬜ | 
| 15 | Baixa | Como aluno, quero realizar as provas no sistema para facilitar meu acesso e ter um ambiente de resolução sem distrações. | 1 e 3 | 8 | ⬜ | 

### 💻 Tecnologias

-   **Versionador:** Github
-   **Ferramenta de gestão:** Github
-   **Linguagem:** Java
-   **Plataforma:** IntelliJ
-   **Interface:** JavaFX e SceneBuilder
-   **Design de Interface:** Canva
-   **Banco de Dados:** MySQL

----

## 📅 Cronograma de Sprints <a id="sprint"></a>

<div align="center">

| Sprint          |    Período    | Documentação                                     |
| :-------------: | :-----------: | :----------------------------------------------: |
|  **SPRINT 1** | 07/09 - 27/09 | [Ver Sprint 1](https://github.com/Equipe-Lovelace-Fatec/API-26-02/blob/main/Docs/sprint1/sprint1.md)|
|  **SPRINT 2** | 05/10 - 25/10 | [Ver Sprint 2](https://github.com/Equipe-Lovelace-Fatec/API-26-02/blob/main/Docs/sprint2/sprint2.md) |
|  **SPRINT 3** | 02/11 - 22/11 | [Ver Sprint 3](https://github.com/Equipe-Lovelace-Fatec/API-26-02/blob/main/Docs/sprint3/sprint3.md) |

</div>


☑️ **Definition of Ready (DoR)** 

-   Não ter dependência de outra User Story;
  
-   User Story e critérios de aceitação detalhados e bem compreendidos pela equipe;

-   Distribuição da User Story ao desenvolvedor e QAs;
 
-   Não ter dependência de outra User Story;
 
-   Ter um esboço da tela em que a User Story funcionará;

-   Definição das informações que devem ser armazenadas para que a User Story seja funcional;

---- 

☑️ **Definition of Done (DoD)**

-   A entrega deve acrescentar valor ao cliente;

-   A entrega deve ser testada pelos QAs da User Story;

-   Os commits precisam seguir o padrão estabelecido pela equipe;
  
-   Documentação do GitHub atualizada, incluindo o Manual de Usuário, com um responsável por sprint;

----
  
### 🛠️ Manual de Instalação
Link para o manual de instalação: [Manual de instalação](https://github.com/Equipe-Lovelace-Fatec/API-26-02/blob/main/Docs/Manuais/Manual%20de%20Instala%C3%A7%C3%A3o.md)


----

### 📘 Manual do Usuário
Link para o manual do usuário: [Manual do usuário](https://github.com/Equipe-Lovelace-Fatec/API-26-02/blob/512f53e476a8e4cf674eaaf60cd3e0fb6be2e89e/Docs/Manuais/Manual%20do%20Usu%C3%A1rio.md)

----

## 📁 Documentação da equipe

<div align="center">

|  [Critérios de Permanência](https://github.com/Equipe-Lovelace-Fatec/API-26-02/blob/main/Docs/Diretrizes%20da%20Equipe/Crit%C3%A9rios%20de%20Perman%C3%AAncia.md)|
|  [Estratégia de Branch](https://github.com/Equipe-Lovelace-Fatec/API-26-02/blob/main/Docs/Diretrizes%20da%20Equipe/Estrat%C3%A9gia%20de%20Branch.md) | 
|  [Padrão de Commit](https://github.com/Equipe-Lovelace-Fatec/API-26-02/blob/main/Docs/Diretrizes%20da%20Equipe/Padr%C3%A3o%20de%20Commit.md) |

</div>


## 👩‍💻 Equipe

<div align="center">
  
| Membro | Função | Github | LinkedIn |
|:----:|:----:|:----:|:----:|
| <img src="https://github.com/user-attachments/assets/11dd9fc5-c8dc-41cf-a0f7-704362f8465a" width="40" style="border-radius:50%" align="left"> Vitória Souza | Product Owner | [![GitHub](https://img.shields.io/badge/GitHub-black?logo=GitHub)](https://github.com/cs-vitoria) | [![LinkedIn](https://img.shields.io/badge/LinkedIn-rgb(10,102,194)?logo=linkedin)](https://www.linkedin.com/in/vit%C3%B3ria-souza-2a9a45391/) |
| <img src="https://github.com/user-attachments/assets/c03a0db3-2613-445a-a0ef-cc28e19a8ce0" width="40" style="border-radius:50%" align="left"> Allana Natasha | Scrum Master | [![GitHub](https://img.shields.io/badge/GitHub-black?logo=GitHub)](https://github.com/AllanaNatasha) | [![LinkedIn](https://img.shields.io/badge/LinkedIn-rgb(10,102,194)?logo=linkedin)](https://www.linkedin.com/in/allana-natasha-gomes?utm_source=share_via&utm_content=profile&utm_medium=member_ios) |
| <img src="https://github.com/user-attachments/assets/ac8b4afa-d858-4b2b-99c6-891b8a55f022" width="40" style="border-radius:50%" align="left"> Amanda Emiliano | Desenvolvedora | [![GitHub](https://img.shields.io/badge/GitHub-black?logo=GitHub)](https://github.com/Amanda-Emiliano) | [![LinkedIn](https://img.shields.io/badge/LinkedIn-rgb(10,102,194)?logo=linkedin)](https://www.linkedin.com/in/amanda-emiliano-0822b2200/) |
| <img src="https://github.com/user-attachments/assets/2dbf9947-2851-49cb-81d3-8dbba358c6c2" width="40" style="border-radius:50%" align="left"> Anderson Ilo | Desenvolvedor | [![GitHub](https://img.shields.io/badge/GitHub-black?logo=GitHub)](https://github.com/AndersonIlo) | [![LinkedIn](https://img.shields.io/badge/LinkedIn-rgb(10,102,194)?logo=linkedin)](https://www.linkedin.com/in/anderson-ilo-212b18182/) |
| <img src="https://github.com/user-attachments/assets/6eb49879-1f88-460c-9303-5f15220ffb4e" width="40" style="border-radius:50%" align="left"> Larissa de Paula | Desenvolvedora | [![GitHub](https://img.shields.io/badge/GitHub-black?logo=GitHub)](https://github.com/larijuno) | [![LinkedIn](https://img.shields.io/badge/LinkedIn-rgb(10,102,194)?logo=linkedin)](https://www.linkedin.com/in/lari-juno/) |
| <img src="https://github.com/user-attachments/assets/80f825c4-04b4-4bda-845c-e6205376506f" width="40" style="border-radius:50%" align="left"> Lívia Dias | Desenvolvedora | [![GitHub](https://img.shields.io/badge/GitHub-black?logo=GitHub)](https://github.com/lili15-star) | [![LinkedIn](https://img.shields.io/badge/LinkedIn-rgb(10,102,194)?logo=linkedin)](https://www.linkedin.com/in/livia-dias-b2977a344) |
| <img src="https://github.com/user-attachments/assets/788c2260-be47-4bb6-8ef9-a5bfd5d9edab" width="40" style="border-radius:50%" align="left"> Vitória Vieira Alves | Desenvolvedora | [![GitHub](https://img.shields.io/badge/GitHub-black?logo=GitHub)](https://github.com/Vitoria2304) | [![LinkedIn](https://img.shields.io/badge/LinkedIn-rgb(10,102,194)?logo=linkedin)](https://www.linkedin.com/in/vitoria-alves-0b28233bb/) |


</div>
